/**
 * 외부 파일 테스트
 */
function prn(){
	for(var i=1;i<=3;i++){
		document.write('test');
	}
}